package com.telebot;

public class config{
  private String botToken="1899585142:AAHmWLwGmy8JWy_12WB70XM1Ykp2lt4GxuI";
  private String botName="DiBot2.0";

  public String getBotToken() {
    return botToken;
  }

  public String getBotName() {
    return botName;
  }
}