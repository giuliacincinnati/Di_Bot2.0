package com.telebot;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

public class MongoDBClient {
    MongoClient mongoClient = MongoClients.create("mongodb+srv://dibot:teamUP00!!@dibot2.klpkm.mongodb.net/test");
    MongoDatabase database = mongoClient.getDatabase("dibot");// take collection

    public MongoCollection<Document> getCollection(String coll) {
        MongoDatabase database = mongoClient.getDatabase("dibot");
        return database.getCollection(coll);
    }

}